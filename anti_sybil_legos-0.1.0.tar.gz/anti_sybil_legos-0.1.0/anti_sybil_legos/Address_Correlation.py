
from scipy.stats import spearmanr
import re
import json
import requests
import pandas as pd

#--------------------------------------------------------------------------------------------------------------------------------------
covalent_api_key = 'ckey_74166d4ccdcf4477926519d28cb'
session = requests.Session() 
session.auth = (covalent_api_key, '')

#--------------------------------------------------------------------------------------------------------------------------------------
sample_sybil_data = pd.read_csv('individual legos/sample_data.csv')
numeric_cols_grant = sample_sybil_data.select_dtypes(include=['float64', 'int64','int32']).columns
sample_sybil_data = sample_sybil_data[numeric_cols_grant]



#--------------------------------------------------------------------------------------------------------------------------------------
def Address_Correlation(address):
    """
    This script is used to gather information about an Ethereum address. It uses the Covalent API to get transaction information and the POKT-Eth API to get the transaction count and current balance of an address. The gathered information is then stored in a DataFrame and returned.

    The script has three main functions:

    get_txn_count(address): This function takes in an Ethereum address as its parameter and returns the number of transactions made from that address using the POKT-Eth API.

    get_transactions_and_date_info(address): This function takes in an Ethereum address as its parameter and returns the number of days the address has been active, the initial funding amount received by the address, the first active day, month and year, and the last active day, month and year using the Covalent API.

    get_balance(address): This function takes in an Ethereum address as its parameter and returns the current balance of the address in ETH using the POKT-Eth API.

    The script also initializes an empty DataFrame named 'data' and assigns column names to it. It also creates a list 'pseudo_dataframe' which is used later in the script.

        Args:
            address (string): An etherium Address
            
        Returns:
            type (Boolean): True,False.

    """

    data = pd.DataFrame([[],[],[],[],[],[],[],[],[],[],[]]).transpose()
    data.rename(columns={0: 'source_wallet', 1: 'txn_count',2:'No_Days_Active',3:'initial_funding',4:'current_balance',5:'first_transaction_day',6:'first_transaction_month',7:'first_transaction_year',8:'last_trasaction_day',9:'last_trasaction_month',10:'last_trasaction_year'},inplace=True)
    pseudo_dataframe = []

#--------------------------------------------------------------------------------------------------------------------------------------
    def get_txn_count(address):
        pokt_eth_endpoint = "https://eth-mainnet.gateway.pokt.network/v1/lb/78cad988d47e553027481226"
        headers = {'content-type': 'application/json'}

        payload = {
            "method": "eth_getTransactionCount",
            "params": [address, "latest"],
            "jsonrpc": "2.0",
            "id": 1,
        }
        response = requests.post(pokt_eth_endpoint, data=json.dumps(payload), headers=headers).json()
        transaction_count = int(response['result'], 16)
        return transaction_count
    
    def get_transactions_and_date_info(address):
        dates = []
        api_key = "api-key"
        transaction_dates = []
        url = f"https://api.covalenthq.com/v1/1/address/{address}/transactions_v2/?no-logs=True"
        
        headers = {
            "x-api-key": covalent_api_key
        }
    
        response = session.get(url, headers=headers)
        txn_data = response.json()['data']['items']
        txn_count = get_txn_count(address)
        for index in range(len(txn_data)):
            dates.append(txn_data[index]['block_signed_at'])

        dates = [*set(dates)]

        first_active_day =  int(re.sub('-','',re.search(r"\d{4}-\d{2}-(\d{2})",txn_data[-1]['block_signed_at']).group(1)))

        first_active_month =  int(re.sub('-','',re.search(r"\d{4}-(\d{2})-\d{2}",txn_data[-1]['block_signed_at']).group(1)))

        first_active_year =  int(re.sub('-','',re.search(r"(\d{4})-\d{2}-\d{2}",txn_data[-1]['block_signed_at']).group(1)))

        last_active_day = int(re.sub('-','',re.search(r"\d{4}-\d{2}-(\d{2})",txn_data[0]['block_signed_at']).group(1)))

        last_active_month = int(re.sub('-','',re.search(r"\d{4}-(\d{2})-\d{2}",txn_data[0]['block_signed_at']).group(1)))

        last_active_year = int(re.sub('-','',re.search(r"(\d{4})-\d{2}-\d{2}",txn_data[0]['block_signed_at']).group(1)))

        inital_ammount_recieved = int(txn_data[-1]['value'])/10**18
        return len(dates),inital_ammount_recieved,first_active_day,first_active_month,first_active_year,last_active_day,last_active_month,last_active_year,txn_count
#--------------------------------------------------------------------------------------------------------------------------------------
    def get_balance(address):
        pokt_Eth_endpoint = "https://eth-mainnet.gateway.pokt.network/v1/lb/78cad988d47e553027481226"
        headers = {'content-type': 'application/json'}

        payload = {
            "method": "eth_getBalance",
            "params": [address, "latest"],
            "jsonrpc": "2.0",
            "id": 1,
        }
        response = requests.post(pokt_Eth_endpoint, data=json.dumps(payload), headers=headers).json()
        balance = int(response['result'], 16)
        balance_in_eth = balance/10**18
        return balance_in_eth

            
#--------------------------------------------------------------------------------------------------------------------------------------

    No_days_active,inital_ammount_recieved,first_active_day,first_active_month,first_active_year,last_active_day,last_active_month,last_active_year,txn_count = get_transactions_and_date_info(address)
    balance =get_balance(address)
    pseudo_dataframe.append(address)
    pseudo_dataframe.append(txn_count)
    pseudo_dataframe.append(No_days_active)
    pseudo_dataframe.append(inital_ammount_recieved)
    pseudo_dataframe.append(balance)
    pseudo_dataframe.append(first_active_day)
    pseudo_dataframe.append(first_active_month)
    pseudo_dataframe.append(first_active_year)
    pseudo_dataframe.append(last_active_day)
    pseudo_dataframe.append(last_active_month)
    pseudo_dataframe.append(last_active_year)
    data.loc[len(data.index)] = pseudo_dataframe

    numeric_cols = data.select_dtypes(include=['float64', 'int64']).columns
    single_row = data[numeric_cols].iloc[0]
    print(single_row)
    correlations = []

    # iterate through rows in second dataframe
    for i, row in sample_sybil_data.iterrows():
        # calculate correlation between single row and current row in second dataframe
        correlation = spearmanr(single_row, row)[0]
        # append correlation value to list
        correlations.append(correlation)

    # set threshold value
    threshold = 0.6


    filtered_correlations = [x for x in correlations if x > threshold]
    if len(filtered_correlations) == 0:
        return False
    else:
        # calculate mean of filtered correlations
        mean_correlation = sum(filtered_correlations) / len(filtered_correlations)
    if threshold < mean_correlation <= 1.0:
        return True
    else:
        return False








