from On_chain_Footprint import On_chain_Footprint_Lego
from Address_Correlation import Address_Correlation
def UCS(address):
    system_one = Address_Correlation(address)
    system_two = On_chain_Footprint_Lego(address)
    system_three = True

    if (system_one == True and system_two == True) or (system_one == True and system_three == True) or (system_two == True and system_three == True):
        return True
    else:
        return False

